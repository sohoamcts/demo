﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CO
{
    public class Rooms
    {
        public int id {get;set;}
        public string hotelname { get; set; }
        public int city { get; set; }
        public string descriptn{get; set;}
        public int noofACs { get; set; }
        public int rentofAC { get; set; }
        public int rentofnonAC { get; set; }
        public int noofrooms { get; set; }
        public DateTime bookedfrom { get; set; }
        public DateTime bookedto { get; set; }
        public int adultcap { get; set; }
        public int childrencap { get; set; }

    }
}
