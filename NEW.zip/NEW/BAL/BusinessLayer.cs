﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using CO;

namespace BAL
{
    public class BusinessLayer
    {
        DataAccess da = new DataAccess();


        //student variables
        public int Sid { get; set; }
        public string Sname { get; set; }
        public string Smarks { get; set; }
        public int standard { get; set; }


        //Hotel Variables

        
        public int Hid { get; set; }
        public string hotelname { get; set; }
        public string cityname { get; set; }
        public string hoteldescription { get; set; }
        public int numberofrooms { get; set; }
        public int rentofroom { get; set; }
        public string offname { get; set; }
        
        //Offer Variables

        public int Oid { get; set; }
        public string offername { get; set; }
        public string offerdescription { get; set; }
        public int percentoff { get; set; }

        //City Variables

        public int Cid { get; set; }
        //public string cityname { get; set; }

        //Customer Variables
        
        public int Csid { get; set; }
        public string Csname{get;set;}
        public string phonenumber{get;set;}
        public string email {get;set;}
        public string password {get;set;}
        public string address{get;set;}
        public string city{get;set;}
        public string pincode{get;set;}
        public string securityQ{get;set;}
        public string securityA{get;set;}

        //Booking Variables
        
        public int Bid{get;set;}
        //public string Csname{get;set;}
        //public string phonenumber{get;set;}
        //public string hotelname{get;set;}
        public int noofrooms{get;set;}
        public int Pid{get;set;}
        public int amount{get;set;}


        //Payment Variables

        //public int Pid{get;set;}
        //public int amount{get;set;}
        //public string Csname{get;set;}
        //public int Bid{get;set;}
        public string bankname{get;set;}
        public string cardno{get;set;}



        SqlCommand cmd = new SqlCommand();

        //public DataSet BL_bind()
        //{
        //    return da.AL_Bind();
        //}

        public DataSet search(string cityname,int noofrooms)
        {
            cmd.Parameters.AddWithValue("@cityname", cityname);
            cmd.Parameters.AddWithValue("@noofroom",noofrooms);
            return da.search_hotel_sp(cmd);
            //cmd.Parameters.AddWithValue("@Csname", Csname);
            //cmd.Parameters.AddWithValue("@password", password);
            //int i = da.login_customer_sp(cmd);
            //return i;
        }

        public DataSet select_hotel()
        {
            return da.select_hotel();
        }

        public DataSet select_city()
        {
            return da.select_city();
        }

        public DataSet select_offer()
        {
            return da.select_offer();
        }

        public DataSet select_booking(int Bid)
        {
            return da.select_booking();
        }

        public DataSet select_payment(int Pid)
        {
            return da.select_payment();
        }

        public int login(string Csname, string password)
        {
            cmd.Parameters.AddWithValue("@Csname", Csname);
            cmd.Parameters.AddWithValue("@password", password);
            int i = da.login_customer_sp(cmd);
            return i;
        }
        //public void insert_data()
        //{
        //    cmd.Parameters.AddWithValue("@sid", Sid);
        //    cmd.Parameters.AddWithValue("@sname",Sname);
        //    cmd.Parameters.AddWithValue("@smarks", Smarks);
        //    cmd.Parameters.AddWithValue("@std", standard);
        //    da.insert_sp(cmd); 
        //}



        public void insert_city()
        {
            cmd.Parameters.AddWithValue("@Cid",Cid);
            cmd.Parameters.AddWithValue("@cityname",cityname);
            da.insert_city_sp(cmd);
        }

        public void update_city(int Cid)
        {
            cmd.Parameters.AddWithValue("@Cid", Cid);
            cmd.Parameters.AddWithValue("@cityname", cityname);
            da.update_city_sp(cmd);
        }

        public void delete_city(int Cid)
        {
            cmd.Parameters.AddWithValue("@Cid", Cid);
            da.delete_city_sp(cmd);
        }

        public void insert_hotel()
        {
            cmd.Parameters.AddWithValue("@Hid", Hid);
            cmd.Parameters.AddWithValue("@hotelname", hotelname);
            cmd.Parameters.AddWithValue("@cityname",cityname);
            cmd.Parameters.AddWithValue("@hoteldescription",hoteldescription);
            cmd.Parameters.AddWithValue("@noofrooms",numberofrooms);
            cmd.Parameters.AddWithValue("@rentofroom",rentofroom);
            cmd.Parameters.AddWithValue("@offername",offername);
            da.insert_hotel_sp(cmd);
        }

        public void update_hotel(int Hid)
        {
            cmd.Parameters.AddWithValue("@Hid", Hid);
            cmd.Parameters.AddWithValue("@hotelname", hotelname);
            cmd.Parameters.AddWithValue("@cityname", cityname);
            cmd.Parameters.AddWithValue("@hoteldescription", hoteldescription);
            cmd.Parameters.AddWithValue("@noofrooms", numberofrooms);
            cmd.Parameters.AddWithValue("@rentofroom", rentofroom);
            cmd.Parameters.AddWithValue("@offername", offername);
            da.update_hotel_sp(cmd);
        }

        public void delete_hotel(int Hid)
        {
            cmd.Parameters.AddWithValue("@Hid", Hid);
            da.delete_hotel_sp(cmd);
        }

        public void insert_customer()
        {
            cmd.Parameters.AddWithValue("@Csname", Csname);
            cmd.Parameters.AddWithValue("@phone", phonenumber);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@passwrd", password);
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Parameters.AddWithValue("@pincode", pincode);
            cmd.Parameters.AddWithValue("@SQ", securityQ);
            cmd.Parameters.AddWithValue("@SA", securityA);
            da.login_customer_sp(cmd);
        }

        public void insert_offer()
        {
            cmd.Parameters.AddWithValue("@Oid", Oid);
            cmd.Parameters.AddWithValue("@offername", offername);
            cmd.Parameters.AddWithValue("@offerdescription", offerdescription);
            cmd.Parameters.AddWithValue("@percentoff", percentoff);
            da.insert_offer_sp(cmd);
        }

        public void update_offer()
        {
            cmd.Parameters.AddWithValue("@Oid", Oid);
            cmd.Parameters.AddWithValue("@offername", offername);
            cmd.Parameters.AddWithValue("@offerdescription", offerdescription);
            cmd.Parameters.AddWithValue("@percentoff", percentoff);
            da.update_offer_sp(cmd);
        }

        public void delete_offer()
        {
            cmd.Parameters.AddWithValue("@Oid", Oid);
            da.delete_offer_sp(cmd);
        }



        public void insert_booking()
        {
            cmd.Parameters.AddWithValue("@Bid", Bid);
            cmd.Parameters.AddWithValue("@Csname", Csname);
            cmd.Parameters.AddWithValue("@phone", phonenumber);
            cmd.Parameters.AddWithValue("@hotelname", hotelname);
            cmd.Parameters.AddWithValue("@numberofroom", numberofrooms);
            cmd.Parameters.AddWithValue("@Pid", Pid);
            cmd.Parameters.AddWithValue("@amount", amount);
            da.booking_sp(cmd);
        }

        public void insert_payment()
        {
            cmd.Parameters.AddWithValue("@Pid", Pid);
            cmd.Parameters.AddWithValue("@amount", amount);
            cmd.Parameters.AddWithValue("@Csname", Csname);
            cmd.Parameters.AddWithValue("@bankname", bankname);
            cmd.Parameters.AddWithValue("@cardno", cardno);
            da.payment_sp(cmd);
        }


        //public void insert_room()
        //{
        //    cmd.Parameters.AddWithValue("@rid",Rid);
        //    cmd.Parameters.AddWithValue("@hotelname",hotelname);
        //    cmd.Parameters.AddWithValue("@cityid",city);
        //    cmd.Parameters.AddWithValue("@desc", descriptn);
        //    cmd.Parameters.AddWithValue("@noofac",noofACs);
        //    cmd.Parameters.AddWithValue("@rentofAC",rentofAC);
        //    cmd.Parameters.AddWithValue("@rentofnonAC", rentofnonAC);
        //    cmd.Parameters.AddWithValue("@noofrooms", noofrooms);
        //    cmd.Parameters.AddWithValue("@bookedfrom", bookedfrom);
        //    cmd.Parameters.AddWithValue("@bookedto", bookedto);
        //    cmd.Parameters.AddWithValue("@adltcap", adultcap);
        //    cmd.Parameters.AddWithValue("@childrencap", childrencap);
        //    da.insert_room_sp(cmd);

        //}

        //public void update_data(int Sid)
        //{
        //    cmd.Parameters.AddWithValue("@sid",Sid);
        //    cmd.Parameters.AddWithValue("@sname", Sname);
        //    cmd.Parameters.AddWithValue("@smarks", Smarks);
        //    cmd.Parameters.AddWithValue("@std", standard);
        //    da.update_sp(cmd);
        //}

        //public void delete_data(int Sid)
        //{
        //    cmd.Parameters.AddWithValue("@sid",Sid);
        //    da.delete_sp(cmd);
        //}
    }
}
