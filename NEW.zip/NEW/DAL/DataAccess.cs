﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
    public class DataAccess
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["newdb"].ConnectionString);

        //public DataSet AL_Bind()
        //{
        //    SqlDataAdapter sda = new SqlDataAdapter("select_sp", con);
        //    DataSet ds = new DataSet();
        //    sda.Fill(ds);
        //    return ds;
        //}

        public DataSet select_hotel()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select_hotel_sp", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public DataSet select_city()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select_city_sp", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public DataSet select_offer()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select_offer_sp", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public DataSet select_booking()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select_booking", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public DataSet select_payment()
        {
            SqlDataAdapter sda = new SqlDataAdapter("select_payment", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public void insert_hotel_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "insert_hotel_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public void update_hotel_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "update_hotel_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public void delete_hotel_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "delete_hotel_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public void insert_offer_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "insert_offer_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public void update_offer_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "update_offer_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public void delete_offer_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "delete_offer_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public void insert_city_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "insert_city_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public void update_city_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "update_city_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public void delete_city_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "delete_city_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public DataSet search_hotel_sp(SqlCommand cmd)
        {
            //con.Open();
            //cmd.Connection = con;
            //cmd.CommandText = "search_hotel_sp";
            //cmd.CommandType = CommandType.StoredProcedure;
            //return cmd.ExecuteNonQuery();
            SqlDataAdapter sda = new SqlDataAdapter("search_hotel_sp", con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            return ds;
        }

        public void insert_customer_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "insert_customer_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public int login_customer_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "login_customer_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            return cmd.ExecuteNonQuery();
        }

        public void booking_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "booking_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }

        public void payment_sp(SqlCommand cmd)
        {
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "payment_sp";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
        }
        

        //public void update_sp(SqlCommand cmd)
        //{
        //    con.Open();
        //    cmd.Connection = con;
        //    cmd.CommandText = "update_sp";
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.ExecuteNonQuery();
        //}

        //public void delete_sp(SqlCommand cmd)
        //{
        //    con.Open();
        //    cmd.Connection = con;
        //    cmd.CommandText = "delete_sp";
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.ExecuteNonQuery();
        //}



    }
}
