﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAL;

namespace reg
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        BusinessLayer bl = new BusinessLayer();
        protected void Page_Load(object sender, EventArgs e)
        {
            GridBind();
        }

        public void GridBind()
        {
            GridView1.DataSource = bl.select_hotel();
            GridView1.DataBind();
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            bl.hotelname = TextBox2.Text;
            bl.cityname = DropDownList1.SelectedValue;
            bl.hoteldescription = TextBox7.Text;
            bl.numberofrooms = Convert.ToInt32(TextBox4.Text);
            bl.rentofroom = Convert.ToInt32(TextBox5.Text);
            bl.offername = DropDownList2.SelectedValue;
            bl.insert_hotel();
            GridBind();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            bl.Hid = Convert.ToInt32(TextBox1.Text);
            bl.hotelname = TextBox2.Text;
            bl.cityname = DropDownList1.SelectedValue;
            bl.hoteldescription = TextBox7.Text;
            bl.numberofrooms = Convert.ToInt32(TextBox4.Text);
            bl.rentofroom = Convert.ToInt32(TextBox5.Text);
            bl.offername = DropDownList2.SelectedValue;
            bl.update_hotel(bl.Hid);
            GridBind();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }
    }
}