﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace reg
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = "Welcome "+Session["cc"].ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["c1"] = DropDownList1.SelectedValue;
            Session["c2"] = TextBox1.Text;
            Response.Redirect("Hotel.aspx");
        }
    }
}