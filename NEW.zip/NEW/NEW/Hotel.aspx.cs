﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAL;

namespace NEW
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        BusinessLayer bl = new BusinessLayer();
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = Session["c1"].ToString();
            Label2.Text = Session["c2"].ToString();
            bl.cityname = Label1.Text;
            bl.noofrooms = Convert.ToInt32(Label2.Text);
            GridView1.DataSource = bl.search(bl.cityname, bl.noofrooms);
            GridView1.DataBind();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}