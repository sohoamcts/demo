﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAL;

namespace NEW
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        BusinessLayer bl = new BusinessLayer();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            bl.Csname = TextBox1.Text;
            bl.phonenumber = TextBox2.Text;
            bl.email = TextBox3.Text;
            bl.password = TextBox4.Text;
            bl.address = TextBox5.Text;
            bl.city = TextBox6.Text;
            bl.pincode = TextBox7.Text;
            bl.securityQ = DropDownList1.SelectedValue;
            bl.securityA = TextBox9.Text;
            bl.insert_customer();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}