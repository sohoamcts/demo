﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BAL;
using CO;

namespace NEW
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        BusinessLayer bl = new BusinessLayer();
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        //public void GridBind()
        //{
        //    GridView1.DataSource = bl.BL_bind();
        //    GridView1.DataBind();
        //}

        //protected void Button2_Click(object sender, EventArgs e)
        //{

        //    bl.Sname = TextBox2.Text;
        //    bl.Smarks = TextBox3.Text;
        //    bl.standard = Convert.ToInt32(TextBox4.Text);
        //    bl.insert_data();
        //    GridBind();
        //}

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    bl.Sid = Convert.ToInt32(TextBox1.Text);
        //    bl.Sname = TextBox2.Text;
        //    bl.Smarks = TextBox3.Text;
        //    bl.standard = Convert.ToInt32(TextBox4.Text);
        //    bl.update_data(bl.Sid);
        //    GridBind();
        //}

        //protected void Button3_Click(object sender, EventArgs e)
        //{
        //    bl.Sid = Convert.ToInt32(TextBox1.Text);
        //    bl.delete_data(bl.Sid);
        //    GridBind();
        //}

        protected void Button1_Click1(object sender, EventArgs e)
        {
            //Rooms rm = new Rooms();
            bl.hotelname = TextBox1.Text;
            bl.city = Convert.ToInt32(TextBox2.Text);
            bl.descriptn = TextBox3.Text;
            bl.noofACs = Convert.ToInt32(TextBox4.Text);
            bl.rentofAC = Convert.ToInt32(TextBox5.Text);
            bl.rentofnonAC = Convert.ToInt32(TextBox6.Text);
            bl.noofrooms = Convert.ToInt32(TextBox7.Text);
            bl.bookedfrom =TextBox8.Text;
            bl.bookedto = TextBox9.Text;
            bl.adultcap = Convert.ToInt32(TextBox10.Text);
            bl.childrencap = Convert.ToInt32(TextBox11.Text);
            bl.insert_room();
            //GridBind();
        }


    }
}