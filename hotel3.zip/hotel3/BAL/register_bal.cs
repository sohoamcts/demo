﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using BAL;
using DAL;
using BUSINESS_OBJECT;

namespace BAL
{
    public class register_bal
    {
        public string insertcustomer(register_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.User_Registration(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
            //finally
            //{
            //    data_object_I = null;
            //}

        }

        public int user_login_process(register_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return (int)data_object_I.User_Login(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
        }
        public string inserthotel(hotel_object cs)
        {
            register_dal data_object_I = new register_dal();
            try
            {
                return data_object_I.Hotel_Insert(cs);
            }
            catch (Exception error)
            {
                throw error;
            }
            //finally
            //{
            //    data_object_I = null;
            //}

        }
    }
}
