﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BUSINESS_OBJECT;
using BAL;

namespace reg
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            //hotel_object ho = new hotel_object();
            //ho.hotel_name = TextBox1.Text;
            //ho.city_name = DropDownList1.SelectedValue;
            //ho.hotel_desc = TextBox3.Text;
            //ho.no_of_rooms = TextBox4.Text;
            //ho.offer_id = DropDownList2.SelectedValue;
            //ho.rent_of_room = TextBox2.Text;
            //register_bal ro = new register_bal();
            //string msg = ro.inserthotel(ho);
        }
        protected void Button3_Click(object sender, EventArgs e)
        {

        }
}
}